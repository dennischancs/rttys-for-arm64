module.exports = {
  pages: {
    index: {
      entry: 'src/main.ts',
      title: 'Rttys'
    }
  },
  pluginOptions: {
    i18n: {
      locale: 'en',
      fallbackLocale: 'en',
      localeDir: 'locales',
      enableInSFC: false
    }
  },
  devServer: {
    proxy: {
      '/rttys/devs': {
        target: 'http://127.0.0.1:5913'
      },
      '/rttys/signin': {
        target: 'http://127.0.0.1:5913'
      },
      '/rttys/cmd/*': {
        target: 'http://127.0.0.1:5913'
      },
      '/rttys/connect/*': {
        ws: true,
        target: 'http://127.0.0.1:5913'
      },
      '/rttys/fontsize/*': {
        target: 'http://127.0.0.1:5913'
      },
      '/rttys/authorized/*': {
        target: 'http://127.0.0.1:5913'
      }
    }
  }
};
